-- phpMyAdmin SQL Dump
-- version 2.11.3deb1ubuntu1.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Set 28, 2010 as 05:53 PM
-- Versão do Servidor: 5.0.51
-- Versão do PHP: 5.2.4-2ubuntu5.12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Banco de Dados: `abrigo`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `acolhido`
--

CREATE TABLE IF NOT EXISTS `acolhido` (
  `id` bigint(20) NOT NULL auto_increment,
  `nome` varchar(255) NOT NULL,
  `sexo` varchar(9) NOT NULL,
  `datanascimento` date default NULL,
  `dataingresso` date default NULL,
  `motivoingresso_id` bigint(20) NOT NULL,
  `processosrelacionados` text,
  `zona` varchar(100) default NULL,
  `distrito` varchar(100) default NULL,
  `livro` varchar(100) default NULL,
  `folha` varchar(100) default NULL,
  `termo` varchar(100) default NULL,
  `documentoidentidade` varchar(100) default NULL,
  `cpf` varchar(100) default NULL,
  `titulo` varchar(100) default NULL,
  `carteiratrabalho` varchar(100) default NULL,
  `possuideficiencia` varchar(3) NOT NULL default 'Não',
  `descricaodeficiencia` text,
  `usomedicamentocontrolado` varchar(3) NOT NULL default 'Não',
  `descricaomedicamentocontrolado` text,
  `mae_id` bigint(20) default NULL,
  `pai_id` bigint(20) default NULL,
  `responsavel_id` bigint(20) default NULL,
  `responsavelgrauparentesco_id` bigint(20) default NULL,
  `sumariosocial` text,
  `sumariopsicologico` text,
  `datadesligamento` date default NULL,
  `motivodesligamento_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `motivoingresso_id_idx` (`motivoingresso_id`),
  KEY `motivodesligamento_id_idx` (`motivodesligamento_id`),
  KEY `pai_id_idx` (`pai_id`),
  KEY `mae_id_idx` (`mae_id`),
  KEY `responsavel_id_idx` (`responsavel_id`),
  KEY `responsavelgrauparentesco_id_idx` (`responsavelgrauparentesco_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Extraindo dados da tabela `acolhido`
--

INSERT INTO `acolhido` (`id`, `nome`, `sexo`, `datanascimento`, `dataingresso`, `motivoingresso_id`, `processosrelacionados`, `zona`, `distrito`, `livro`, `folha`, `termo`, `documentoidentidade`, `cpf`, `titulo`, `carteiratrabalho`, `possuideficiencia`, `descricaodeficiencia`, `usomedicamentocontrolado`, `descricaomedicamentocontrolado`, `mae_id`, `pai_id`, `responsavel_id`, `responsavelgrauparentesco_id`, `sumariosocial`, `sumariopsicologico`, `datadesligamento`, `motivodesligamento_id`) VALUES
(1, 'João Carlos', 'Masculino', '1987-11-12', NULL, 1, '', '', '', '', '', '', '', '', '', '', 'Não', '', 'Não', '', 1, 2, 1, NULL, '', '', '2009-01-16', NULL),
(2, 'Miguel Castro', 'Masculino', '1987-11-22', NULL, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Sim', NULL, 'Não', NULL, 3, 2, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'Isabela Miranda', 'Feminino', NULL, NULL, 2, '', '', '', '', '', '', '', '', '', '', 'Não', '', 'Não', '', 1, 2, NULL, NULL, '', '', '2010-08-13', NULL),
(4, 'Beatriz de Albuquerque', 'Feminino', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Não', NULL, 'Sim', NULL, 3, 2, NULL, NULL, NULL, NULL, '2010-05-22', 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `apadrinhamento`
--

CREATE TABLE IF NOT EXISTS `apadrinhamento` (
  `acolhido_id` bigint(20) NOT NULL default '0',
  `padrinho_id` bigint(20) NOT NULL default '0',
  `datainicio` date NOT NULL,
  `datafim` date default NULL,
  `observacoes` text,
  PRIMARY KEY  (`acolhido_id`,`padrinho_id`),
  KEY `apadrinhamento_padrinho_id_padrinho_id` (`padrinho_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `apadrinhamento`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `curso_externo_acolhido`
--

CREATE TABLE IF NOT EXISTS `curso_externo_acolhido` (
  `id` bigint(20) NOT NULL auto_increment,
  `acolhido_id` bigint(20) default NULL,
  `nomecurso` varchar(255) NOT NULL,
  `descricao` text,
  `nomeescola` varchar(255) NOT NULL,
  `dataconclusao` date default NULL,
  PRIMARY KEY  (`id`),
  KEY `acolhido_id_idx` (`acolhido_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Extraindo dados da tabela `curso_externo_acolhido`
--

INSERT INTO `curso_externo_acolhido` (`id`, `acolhido_id`, `nomecurso`, `descricao`, `nomeescola`, `dataconclusao`) VALUES
(1, 1, 'Informática Básica', 'Windows XP, Office 2007 ( Word, Excel e Powerpoint) e Internet', 'FAETEC', '2009-11-12'),
(2, 2, 'Inglês Instrumental', 'Leitura e interpretação de textos em lingua inglesa.', 'FAETEC', '2009-05-07'),
(3, 3, 'Computação Gráfica', 'Corel Draw, PhotoShop e Gimp', 'FAETEC', '2009-11-12'),
(4, 4, 'WebDesign', 'HTML, CSS, Javascript, Flash e PHP.', 'FAETEC', '2009-11-12');

-- --------------------------------------------------------

--
-- Estrutura da tabela `entidades_passadas_acolhido`
--

CREATE TABLE IF NOT EXISTS `entidades_passadas_acolhido` (
  `id` bigint(20) NOT NULL auto_increment,
  `acolhido_id` bigint(20) NOT NULL,
  `nomeentidade` varchar(255) NOT NULL,
  `dataentrada` date NOT NULL,
  `datasaida` date NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `acolhido_id_idx` (`acolhido_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Extraindo dados da tabela `entidades_passadas_acolhido`
--

INSERT INTO `entidades_passadas_acolhido` (`id`, `acolhido_id`, `nomeentidade`, `dataentrada`, `datasaida`) VALUES
(1, 1, 'Abrigo Fulano de tal', '2009-05-07', '2009-05-10'),
(2, 2, 'Abrigo Ciclano de tal', '2009-05-07', '2009-05-10'),
(3, 3, 'Orfanato Fulano de tal', '2009-05-07', '2009-05-10'),
(4, 4, 'Orfanato Ciclano de tal', '2009-05-07', '2009-05-10');

-- --------------------------------------------------------

--
-- Estrutura da tabela `entradas_e_saidas_acolhido`
--

CREATE TABLE IF NOT EXISTS `entradas_e_saidas_acolhido` (
  `id` bigint(20) NOT NULL auto_increment,
  `acolhido_id` bigint(20) NOT NULL,
  `mae_id` bigint(20) default NULL,
  `pai_id` bigint(20) default NULL,
  `responsavel_id` bigint(20) default NULL,
  `voluntario_id` bigint(20) default NULL,
  `padrinho_id` bigint(20) default NULL,
  `datasaida` datetime NOT NULL,
  `dataprevistaretorno` datetime NOT NULL,
  `dataretorno` datetime default NULL,
  `observacoes` text,
  PRIMARY KEY  (`id`),
  KEY `acolhido_id_idx` (`acolhido_id`),
  KEY `pai_id_idx` (`pai_id`),
  KEY `mae_id_idx` (`mae_id`),
  KEY `responsavel_id_idx` (`responsavel_id`),
  KEY `voluntario_id_idx` (`voluntario_id`),
  KEY `padrinho_id_idx` (`padrinho_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Extraindo dados da tabela `entradas_e_saidas_acolhido`
--

INSERT INTO `entradas_e_saidas_acolhido` (`id`, `acolhido_id`, `mae_id`, `pai_id`, `responsavel_id`, `voluntario_id`, `padrinho_id`, `datasaida`, `dataprevistaretorno`, `dataretorno`, `observacoes`) VALUES
(1, 1, NULL, NULL, 1, NULL, NULL, '2009-05-07 00:08:00', '2009-05-10 00:17:00', NULL, NULL),
(2, 2, NULL, NULL, 2, NULL, NULL, '2009-05-07 00:08:00', '2009-05-10 00:17:00', NULL, NULL),
(3, 3, NULL, NULL, 1, NULL, NULL, '2009-05-07 00:08:00', '2009-05-10 00:17:00', '2009-05-10 00:17:00', NULL),
(4, 4, NULL, NULL, 2, NULL, NULL, '2009-05-07 00:08:00', '2009-05-10 00:17:00', '2009-05-10 00:17:00', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `escolaridade_acolhido`
--

CREATE TABLE IF NOT EXISTS `escolaridade_acolhido` (
  `acolhido_id` bigint(20) NOT NULL default '0',
  `escolaridade_id` bigint(20) NOT NULL default '0',
  `nomeescola` varchar(255) NOT NULL,
  `dataconclusao` date default NULL,
  PRIMARY KEY  (`acolhido_id`,`escolaridade_id`),
  KEY `escolaridade_acolhido_escolaridade_id_nivel_escolaridade_id` (`escolaridade_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `escolaridade_acolhido`
--

INSERT INTO `escolaridade_acolhido` (`acolhido_id`, `escolaridade_id`, `nomeescola`, `dataconclusao`) VALUES
(1, 1, 'Colégio Santo Antônio', '2009-11-12'),
(2, 4, 'Colégio Rui Barbosa', '2009-11-12'),
(3, 3, 'Colégio Abel', '2009-11-12'),
(4, 8, 'Colégio Técnico Universitário', '2009-11-12');

-- --------------------------------------------------------

--
-- Estrutura da tabela `grau_parentesco_responsavel`
--

CREATE TABLE IF NOT EXISTS `grau_parentesco_responsavel` (
  `id` bigint(20) NOT NULL auto_increment,
  `nome` varchar(255) NOT NULL,
  `ordem` bigint(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Extraindo dados da tabela `grau_parentesco_responsavel`
--

INSERT INTO `grau_parentesco_responsavel` (`id`, `nome`, `ordem`) VALUES
(1, 'avô / avó', NULL),
(2, 'tio / tia', NULL),
(3, 'irmão / irmã', NULL),
(4, 'primo / prima', NULL),
(5, 'nenhum', NULL),
(6, 'outros', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `motivo_desligamento`
--

CREATE TABLE IF NOT EXISTS `motivo_desligamento` (
  `id` bigint(20) NOT NULL auto_increment,
  `nome` varchar(255) NOT NULL,
  `ordem` bigint(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Extraindo dados da tabela `motivo_desligamento`
--

INSERT INTO `motivo_desligamento` (`id`, `nome`, `ordem`) VALUES
(1, 'reintegração familiar', NULL),
(2, 'evasão', NULL),
(3, 'colocação em família substituta', NULL),
(4, 'alcançou a maioridade', NULL),
(5, 'óbito', NULL),
(6, 'não informado', NULL),
(7, 'outros', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `motivo_ingresso`
--

CREATE TABLE IF NOT EXISTS `motivo_ingresso` (
  `id` bigint(20) NOT NULL auto_increment,
  `nome` varchar(255) NOT NULL,
  `ordem` bigint(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Extraindo dados da tabela `motivo_ingresso`
--

INSERT INTO `motivo_ingresso` (`id`, `nome`, `ordem`) VALUES
(1, 'negligência', NULL),
(2, 'carência de recursos materiais da família ou responsável', NULL),
(3, 'abandono pelos pais ou responsáveis', NULL),
(4, 'violência doméstica (maus tratos físicos ou pisicológicos)', NULL),
(5, 'situação de rua', NULL),
(6, 'pais ou responsáveis dependentes químicos ou alcoolistas', NULL),
(7, 'abuso sexual / suspeita de abuso sexual', NULL),
(8, 'orfandade', NULL),
(9, 'risco de vida na comunidade', NULL),
(10, 'em razão de sua conduta', NULL),
(11, 'falta de creche ou escola em horário integral', NULL),
(12, 'uso abusivo de drogas ou álcool', NULL),
(13, 'não informado', NULL),
(14, 'outros', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `nivel_escolaridade`
--

CREATE TABLE IF NOT EXISTS `nivel_escolaridade` (
  `id` bigint(20) NOT NULL auto_increment,
  `nome` varchar(100) NOT NULL,
  `grau` varchar(100) NOT NULL,
  `ordem` bigint(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Extraindo dados da tabela `nivel_escolaridade`
--

INSERT INTO `nivel_escolaridade` (`id`, `nome`, `grau`, `ordem`) VALUES
(1, '1º Ano', 'ENSINO FUNDAMENTAL', NULL),
(2, '2º Ano', 'ENSINO FUNDAMENTAL', NULL),
(3, '3º Ano', 'ENSINO FUNDAMENTAL', NULL),
(4, '4º Ano', 'ENSINO FUNDAMENTAL', NULL),
(5, '5º Ano', 'ENSINO FUNDAMENTAL', NULL),
(6, '6º Ano', 'ENSINO FUNDAMENTAL', NULL),
(7, '7º Ano', 'ENSINO FUNDAMENTAL', NULL),
(8, '8º Ano', 'ENSINO FUNDAMENTAL', NULL),
(9, '9º Ano', 'ENSINO FUNDAMENTAL', NULL),
(10, '1ª Série', 'ENSINO MÉDIO', NULL),
(11, '2ª Série', 'ENSINO MÉDIO', NULL),
(12, '3ª Série', 'ENSINO MÉDIO', NULL),
(13, 'Graduação', 'ENSINO SUPERIOR', NULL),
(14, 'Pós graduação', 'ENSINO SUPERIOR', NULL),
(15, 'Mestrado', 'ENSINO SUPERIOR', NULL),
(16, 'Doutorado', 'ENSINO SUPERIOR', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `padrinho`
--

CREATE TABLE IF NOT EXISTS `padrinho` (
  `id` bigint(20) NOT NULL auto_increment,
  `nome` varchar(255) NOT NULL,
  `sexo` varchar(9) NOT NULL,
  `datanascimento` date default NULL,
  `endlogradouro` varchar(255) default NULL,
  `endnumero` varchar(50) default NULL,
  `endcomplemento` varchar(50) default NULL,
  `endbairro` varchar(100) default NULL,
  `endcidade` varchar(255) default NULL,
  `endestado` varchar(2) NOT NULL default 'RJ',
  `endcep` varchar(9) default NULL,
  `endproflogradouro` varchar(255) default NULL,
  `endprofnumero` varchar(50) default NULL,
  `endprofcomplemento` varchar(50) default NULL,
  `endprofbairro` varchar(100) default NULL,
  `endprofcidade` varchar(255) default NULL,
  `endprofestado` varchar(2) NOT NULL default 'RJ',
  `endprofcep` varchar(9) default NULL,
  `contatos` text,
  `escolaridade_id` bigint(20) default NULL,
  `profissao` varchar(255) default NULL,
  `composicaofamiliar` text,
  `preferenciareligiosa` text,
  `conhecimentoprograma` text,
  `interessepreliminar` text,
  `observacao` text,
  `datainscricao` date default NULL,
  `tecnicoresponsavel` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `escolaridade_id_idx` (`escolaridade_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `padrinho`
--

INSERT INTO `padrinho` (`id`, `nome`, `sexo`, `datanascimento`, `endlogradouro`, `endnumero`, `endcomplemento`, `endbairro`, `endcidade`, `endestado`, `endcep`, `endproflogradouro`, `endprofnumero`, `endprofcomplemento`, `endprofbairro`, `endprofcidade`, `endprofestado`, `endprofcep`, `contatos`, `escolaridade_id`, `profissao`, `composicaofamiliar`, `preferenciareligiosa`, `conhecimentoprograma`, `interessepreliminar`, `observacao`, `datainscricao`, `tecnicoresponsavel`) VALUES
(1, 'Jorge Macedo Ideal', '', NULL, NULL, NULL, NULL, NULL, 'Três Rios', 'RJ', NULL, NULL, NULL, NULL, NULL, NULL, 'RJ', NULL, NULL, NULL, 'Farmacêutico', NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `pessoa`
--

CREATE TABLE IF NOT EXISTS `pessoa` (
  `id` bigint(20) NOT NULL auto_increment,
  `nome` varchar(255) NOT NULL,
  `sexo` varchar(9) NOT NULL,
  `datanascimento` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `pessoa`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `responsavel`
--

CREATE TABLE IF NOT EXISTS `responsavel` (
  `id` bigint(20) NOT NULL auto_increment,
  `nome` varchar(255) NOT NULL,
  `sexo` varchar(9) NOT NULL,
  `datanascimento` date default NULL,
  `dataobito` date default NULL,
  `endlogradouro` varchar(255) default NULL,
  `endnumero` varchar(50) default NULL,
  `endcomplemento` varchar(50) default NULL,
  `endbairro` varchar(100) default NULL,
  `endcidade` varchar(255) default NULL,
  `endestado` varchar(2) NOT NULL default 'RJ',
  `endcep` varchar(9) default NULL,
  `contatos` text,
  `autorizacaovisita` varchar(3) NOT NULL,
  `observacao` text,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Extraindo dados da tabela `responsavel`
--

INSERT INTO `responsavel` (`id`, `nome`, `sexo`, `datanascimento`, `dataobito`, `endlogradouro`, `endnumero`, `endcomplemento`, `endbairro`, `endcidade`, `endestado`, `endcep`, `contatos`, `autorizacaovisita`, `observacao`) VALUES
(1, 'Fernanda Ricardo da Silva', 'Feminino', NULL, NULL, NULL, NULL, NULL, NULL, 'Três Rios', 'RJ', NULL, NULL, 'Sim', NULL),
(2, 'Luiz Antônio Dias de Oliveira', 'Masculino', NULL, NULL, NULL, NULL, NULL, NULL, 'Três Rios', 'RJ', NULL, NULL, 'Não', NULL),
(3, 'Hosana Vieira da Silva', 'Feminino', NULL, NULL, NULL, NULL, NULL, NULL, 'Três Rios', 'RJ', NULL, NULL, 'Sim', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `sf_guard_group`
--

CREATE TABLE IF NOT EXISTS `sf_guard_group` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `description` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Extraindo dados da tabela `sf_guard_group`
--

INSERT INTO `sf_guard_group` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Administrator group', '2010-08-10 16:48:38', '2010-08-10 16:48:38'),
(2, 'Digitadores', 'Somente entrada de dados', '2010-08-10 16:59:23', '2010-08-10 16:59:23');

-- --------------------------------------------------------

--
-- Estrutura da tabela `sf_guard_group_permission`
--

CREATE TABLE IF NOT EXISTS `sf_guard_group_permission` (
  `group_id` int(11) NOT NULL default '0',
  `permission_id` int(11) NOT NULL default '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY  (`group_id`,`permission_id`),
  KEY `sf_guard_group_permission_permission_id_sf_guard_permission_id` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `sf_guard_group_permission`
--

INSERT INTO `sf_guard_group_permission` (`group_id`, `permission_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2010-08-10 16:48:38', '2010-08-10 16:48:38'),
(1, 2, '2010-08-10 16:59:54', '2010-08-10 16:59:54'),
(1, 3, '2010-08-13 17:06:23', '2010-08-13 17:06:23'),
(2, 2, '2010-08-10 16:59:54', '2010-08-10 16:59:54'),
(2, 3, '2010-08-13 17:06:23', '2010-08-13 17:06:23');

-- --------------------------------------------------------

--
-- Estrutura da tabela `sf_guard_permission`
--

CREATE TABLE IF NOT EXISTS `sf_guard_permission` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `description` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Extraindo dados da tabela `sf_guard_permission`
--

INSERT INTO `sf_guard_permission` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Administrator permission', '2010-08-10 16:48:38', '2010-08-10 16:48:38'),
(2, 'EntradadeDados', 'Entrada de Dados', '2010-08-10 16:59:54', '2010-08-10 16:59:54'),
(3, 'Criar Temática', '', '2010-08-13 17:06:23', '2010-08-13 17:06:23');

-- --------------------------------------------------------

--
-- Estrutura da tabela `sf_guard_remember_key`
--

CREATE TABLE IF NOT EXISTS `sf_guard_remember_key` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) default NULL,
  `remember_key` varchar(32) default NULL,
  `ip_address` varchar(50) NOT NULL default '',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY  (`id`,`ip_address`),
  KEY `user_id_idx` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `sf_guard_remember_key`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `sf_guard_user`
--

CREATE TABLE IF NOT EXISTS `sf_guard_user` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(128) NOT NULL,
  `algorithm` varchar(128) NOT NULL default 'sha1',
  `salt` varchar(128) default NULL,
  `password` varchar(128) default NULL,
  `is_active` tinyint(1) default '1',
  `is_super_admin` tinyint(1) default '0',
  `last_login` datetime default NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `is_active_idx_idx` (`is_active`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Extraindo dados da tabela `sf_guard_user`
--

INSERT INTO `sf_guard_user` (`id`, `username`, `algorithm`, `salt`, `password`, `is_active`, `is_super_admin`, `last_login`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'sha1', '564acbd18cc8a1882d6ec45a0ed7d655', '6585b9adc8876c79baf3631167089ec24a31b469', 1, 1, '2010-09-22 17:18:56', '2010-08-10 16:48:38', '2010-09-22 17:18:56'),
(2, 'luiz', 'sha1', 'd7777212fd023f6e0cb390cf987a8a5b', '903f31f964218514bde817c6007aaaf71f19ca48', 1, 0, '2010-09-22 17:26:09', '2010-09-22 17:25:58', '2010-09-22 17:26:09');

-- --------------------------------------------------------

--
-- Estrutura da tabela `sf_guard_user_group`
--

CREATE TABLE IF NOT EXISTS `sf_guard_user_group` (
  `user_id` int(11) NOT NULL default '0',
  `group_id` int(11) NOT NULL default '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY  (`user_id`,`group_id`),
  KEY `sf_guard_user_group_group_id_sf_guard_group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `sf_guard_user_group`
--

INSERT INTO `sf_guard_user_group` (`user_id`, `group_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2010-08-10 16:48:38', '2010-08-10 16:48:38');

-- --------------------------------------------------------

--
-- Estrutura da tabela `sf_guard_user_permission`
--

CREATE TABLE IF NOT EXISTS `sf_guard_user_permission` (
  `user_id` int(11) NOT NULL default '0',
  `permission_id` int(11) NOT NULL default '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY  (`user_id`,`permission_id`),
  KEY `sf_guard_user_permission_permission_id_sf_guard_permission_id` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `sf_guard_user_permission`
--

INSERT INTO `sf_guard_user_permission` (`user_id`, `permission_id`, `created_at`, `updated_at`) VALUES
(2, 1, '2010-09-22 17:26:40', '2010-09-22 17:26:40');

-- --------------------------------------------------------

--
-- Estrutura da tabela `voluntario`
--

CREATE TABLE IF NOT EXISTS `voluntario` (
  `id` bigint(20) NOT NULL auto_increment,
  `nome` varchar(255) NOT NULL,
  `sexo` varchar(9) NOT NULL,
  `datanascimento` date default NULL,
  `endlogradouro` varchar(255) default NULL,
  `endnumero` varchar(50) default NULL,
  `endcomplemento` varchar(50) default NULL,
  `endbairro` varchar(100) default NULL,
  `endcidade` varchar(255) default NULL,
  `endestado` varchar(2) NOT NULL default 'RJ',
  `endcep` varchar(9) default NULL,
  `endproflogradouro` varchar(255) default NULL,
  `endprofnumero` varchar(50) default NULL,
  `endprofcomplemento` varchar(50) default NULL,
  `endprofbairro` varchar(100) default NULL,
  `endprofcidade` varchar(255) default NULL,
  `endprofestado` varchar(2) NOT NULL default 'RJ',
  `endprofcep` varchar(9) default NULL,
  `contatos` text,
  `escolaridade_id` bigint(20) default NULL,
  `profissao` varchar(255) default NULL,
  `composicaofamiliar` text,
  `preferenciareligiosa` text,
  `conhecimentoprograma` text,
  `disponibilidadehorario` text,
  `atividadedesenvolvida` text,
  `observacao` text,
  `datainscricao` date default NULL,
  `tecnicoresponsavel` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `escolaridade_id_idx` (`escolaridade_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `voluntario`
--

INSERT INTO `voluntario` (`id`, `nome`, `sexo`, `datanascimento`, `endlogradouro`, `endnumero`, `endcomplemento`, `endbairro`, `endcidade`, `endestado`, `endcep`, `endproflogradouro`, `endprofnumero`, `endprofcomplemento`, `endprofbairro`, `endprofcidade`, `endprofestado`, `endprofcep`, `contatos`, `escolaridade_id`, `profissao`, `composicaofamiliar`, `preferenciareligiosa`, `conhecimentoprograma`, `disponibilidadehorario`, `atividadedesenvolvida`, `observacao`, `datainscricao`, `tecnicoresponsavel`) VALUES
(1, 'Luiz Felipe Silva Oliveira', '', NULL, NULL, NULL, NULL, NULL, 'Três Rios', 'RJ', NULL, NULL, NULL, NULL, NULL, NULL, 'RJ', NULL, NULL, NULL, 'Analista de Sistemas', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

--
-- Restrições para as tabelas dumpadas
--

--
-- Restrições para a tabela `acolhido`
--
ALTER TABLE `acolhido`
  ADD CONSTRAINT `acolhido_mae_id_responsavel_id` FOREIGN KEY (`mae_id`) REFERENCES `responsavel` (`id`),
  ADD CONSTRAINT `acolhido_motivodesligamento_id_motivo_desligamento_id` FOREIGN KEY (`motivodesligamento_id`) REFERENCES `motivo_desligamento` (`id`),
  ADD CONSTRAINT `acolhido_motivoingresso_id_motivo_ingresso_id` FOREIGN KEY (`motivoingresso_id`) REFERENCES `motivo_ingresso` (`id`),
  ADD CONSTRAINT `acolhido_pai_id_responsavel_id` FOREIGN KEY (`pai_id`) REFERENCES `responsavel` (`id`),
  ADD CONSTRAINT `acolhido_responsavel_id_responsavel_id` FOREIGN KEY (`responsavel_id`) REFERENCES `responsavel` (`id`),
  ADD CONSTRAINT `argi` FOREIGN KEY (`responsavelgrauparentesco_id`) REFERENCES `grau_parentesco_responsavel` (`id`);

--
-- Restrições para a tabela `apadrinhamento`
--
ALTER TABLE `apadrinhamento`
  ADD CONSTRAINT `apadrinhamento_acolhido_id_acolhido_id` FOREIGN KEY (`acolhido_id`) REFERENCES `acolhido` (`id`),
  ADD CONSTRAINT `apadrinhamento_padrinho_id_padrinho_id` FOREIGN KEY (`padrinho_id`) REFERENCES `padrinho` (`id`);

--
-- Restrições para a tabela `curso_externo_acolhido`
--
ALTER TABLE `curso_externo_acolhido`
  ADD CONSTRAINT `curso_externo_acolhido_acolhido_id_acolhido_id` FOREIGN KEY (`acolhido_id`) REFERENCES `acolhido` (`id`);

--
-- Restrições para a tabela `entidades_passadas_acolhido`
--
ALTER TABLE `entidades_passadas_acolhido`
  ADD CONSTRAINT `entidades_passadas_acolhido_acolhido_id_acolhido_id` FOREIGN KEY (`acolhido_id`) REFERENCES `acolhido` (`id`);

--
-- Restrições para a tabela `entradas_e_saidas_acolhido`
--
ALTER TABLE `entradas_e_saidas_acolhido`
  ADD CONSTRAINT `entradas_e_saidas_acolhido_acolhido_id_acolhido_id` FOREIGN KEY (`acolhido_id`) REFERENCES `acolhido` (`id`),
  ADD CONSTRAINT `entradas_e_saidas_acolhido_mae_id_responsavel_id` FOREIGN KEY (`mae_id`) REFERENCES `responsavel` (`id`),
  ADD CONSTRAINT `entradas_e_saidas_acolhido_padrinho_id_padrinho_id` FOREIGN KEY (`padrinho_id`) REFERENCES `padrinho` (`id`),
  ADD CONSTRAINT `entradas_e_saidas_acolhido_pai_id_responsavel_id` FOREIGN KEY (`pai_id`) REFERENCES `responsavel` (`id`),
  ADD CONSTRAINT `entradas_e_saidas_acolhido_responsavel_id_responsavel_id` FOREIGN KEY (`responsavel_id`) REFERENCES `responsavel` (`id`),
  ADD CONSTRAINT `entradas_e_saidas_acolhido_voluntario_id_voluntario_id` FOREIGN KEY (`voluntario_id`) REFERENCES `voluntario` (`id`);

--
-- Restrições para a tabela `escolaridade_acolhido`
--
ALTER TABLE `escolaridade_acolhido`
  ADD CONSTRAINT `escolaridade_acolhido_acolhido_id_acolhido_id` FOREIGN KEY (`acolhido_id`) REFERENCES `acolhido` (`id`),
  ADD CONSTRAINT `escolaridade_acolhido_escolaridade_id_nivel_escolaridade_id` FOREIGN KEY (`escolaridade_id`) REFERENCES `nivel_escolaridade` (`id`);

--
-- Restrições para a tabela `padrinho`
--
ALTER TABLE `padrinho`
  ADD CONSTRAINT `padrinho_escolaridade_id_nivel_escolaridade_id` FOREIGN KEY (`escolaridade_id`) REFERENCES `nivel_escolaridade` (`id`);

--
-- Restrições para a tabela `sf_guard_group_permission`
--
ALTER TABLE `sf_guard_group_permission`
  ADD CONSTRAINT `sf_guard_group_permission_group_id_sf_guard_group_id` FOREIGN KEY (`group_id`) REFERENCES `sf_guard_group` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sf_guard_group_permission_permission_id_sf_guard_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `sf_guard_permission` (`id`) ON DELETE CASCADE;

--
-- Restrições para a tabela `sf_guard_remember_key`
--
ALTER TABLE `sf_guard_remember_key`
  ADD CONSTRAINT `sf_guard_remember_key_user_id_sf_guard_user_id` FOREIGN KEY (`user_id`) REFERENCES `sf_guard_user` (`id`) ON DELETE CASCADE;

--
-- Restrições para a tabela `sf_guard_user_group`
--
ALTER TABLE `sf_guard_user_group`
  ADD CONSTRAINT `sf_guard_user_group_group_id_sf_guard_group_id` FOREIGN KEY (`group_id`) REFERENCES `sf_guard_group` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sf_guard_user_group_user_id_sf_guard_user_id` FOREIGN KEY (`user_id`) REFERENCES `sf_guard_user` (`id`) ON DELETE CASCADE;

--
-- Restrições para a tabela `sf_guard_user_permission`
--
ALTER TABLE `sf_guard_user_permission`
  ADD CONSTRAINT `sf_guard_user_permission_permission_id_sf_guard_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `sf_guard_permission` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sf_guard_user_permission_user_id_sf_guard_user_id` FOREIGN KEY (`user_id`) REFERENCES `sf_guard_user` (`id`) ON DELETE CASCADE;

--
-- Restrições para a tabela `voluntario`
--
ALTER TABLE `voluntario`
  ADD CONSTRAINT `voluntario_escolaridade_id_nivel_escolaridade_id` FOREIGN KEY (`escolaridade_id`) REFERENCES `nivel_escolaridade` (`id`);
